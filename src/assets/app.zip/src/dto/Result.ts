import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class Result {
    [key: string]: any;
    @ApiProperty({
        required: false,
    })
    cv_error?: Record<string, string[]>;
}