import {Field, ArgsType} from '@nestjs/graphql';
import {ApiProperty} from '@nestjs/swagger';
import {EntityMetadata, Equal, In, LessThan, LessThanOrEqual, MoreThan, MoreThanOrEqual, Not, Raw} from 'typeorm';
import {ColumnMetadata} from 'typeorm/metadata/ColumnMetadata';
import {isEmpty} from './Base';
import * as qs from 'qs';

@ArgsType()
export class Order {
    @ApiProperty({
        required: true,
        enum: ['ASC', 'DESC'],
    })
    @Field()
    direction: 'ASC' | 'DESC';
    @ApiProperty({
        required: true,
    })
    @Field()
    property: string;
}
@ArgsType()
export class Filter {
    @ApiProperty({
        required: true,
        enum: ['gt', '>', 'ge', '>=', 'lt', '<', 'le', '<=', 'eq', '=', 'like', 'in', 'not in'],
    })
    @Field()
    operator: string;
    @ApiProperty({
        required: true,
    })
    @Field()
    property: string;
    @ApiProperty({
        required: true,
        oneOf: [
            {
                type: 'integer',
            },
            {
                type: 'number',
            },
            {
                type: 'string',
            },
            {
                type: 'boolean',
            },
            {
                type: 'array',
                items: {
                    oneOf: [
                        {
                            type: 'integer',
                        },
                        {
                            type: 'number',
                        },
                        {
                            type: 'string',
                        },
                        {
                            type: 'boolean',
                        },
                    ],
                },
            },
        ],
    })
    @Field(() => String)
    value: string;
}

export const plainToEntity = (entity: EntityMetadata, target: Record<string, any> = {}) => {
    return entity.columns.reduce((res, meta: ColumnMetadata) => {
        let value = target[meta.propertyName];
        if (isEmpty(value)) {
            if (meta.referencedColumn) {
                value = Object.prototype.hasOwnProperty.call(target, meta.databaseName)
                    ? {
                          [meta.referencedColumn.databaseName]: target[meta.databaseName],
                      }
                    : undefined;
            } else {
                value = target[meta.databaseName];
            }
        }
        if (!isEmpty(value)) {
            res[meta.propertyName] = value;
        }
        return res;
    }, {});
};

export const filterEqualsEntity = (entity: EntityMetadata, target: Record<string, any> = {}) => {
    return entity.columns.reduce((res, meta: ColumnMetadata) => {
        let value = target[meta.propertyName];
        if (isEmpty(value)) {
            if (meta.referencedColumn) {
                value = Object.prototype.hasOwnProperty.call(target, meta.databaseName)
                    ? {
                          [meta.referencedColumn.databaseName]: target[meta.databaseName],
                      }
                    : undefined;
            } else {
                value = target[meta.databaseName];
            }
        }
        if (!isEmpty(value)) {
            if (typeof value === 'string' && value.startsWith('[') && value.endsWith(']')) {
                value = JSON.parse(value);
            }
            res[meta.propertyName] = Array.isArray(value) ? In(value) : value;
        }
        return res;
    }, {});
};

export const filterEntity = (
    entity: EntityMetadata,
    target: string | string[] | qs.ParsedQs | qs.ParsedQs[] | Filter[] = [],
) => {
    if (typeof target === 'string' && target.startsWith('{')) {
        target = [JSON.parse(target)];
    }
    if (typeof target === 'string' && target.startsWith('[')) {
        target = JSON.parse(target);
    }
    if (Array.isArray(target)) {
        if (typeof target[0] === 'string') {
            target = target.map((val) => JSON.parse(val));
        }
    } else {
        target = [];
    }
    return entity.columns.reduce((res, meta: ColumnMetadata) => {
        const filter = (target as Filter[]).find((val) =>
            val.property
                ? val.property.split('.')[0] === meta.propertyName || val.property === meta.databaseName
                : false,
        );
        if (filter && filter.operator) {
            const filterProperties = filter.property.split('.');
            let last = meta.propertyName;
            let val = res;
            if (filterProperties.length > 1) {
                last = filterProperties.pop();
                val = filterProperties.reduce((result, value) => {
                    result[value] = {};
                    return result[value];
                }, res);
            }
            switch (filter.operator) {
                case 'gt':
                case '>':
                    val[last] = MoreThan(filter.value);
                    break;
                case 'ge':
                case '>=':
                    val[last] = MoreThanOrEqual(filter.value);
                    break;
                case 'lt':
                case '<':
                    val[last] = LessThan(filter.value);
                    break;
                case 'le':
                case '<=':
                    val[last] = LessThanOrEqual(filter.value);
                    break;
                case 'eq':
                case '=':
                    val[last] = Equal(filter.value);
                    break;
                case 'like':
                    val[last] = Raw((alias) => `UPPER(${alias}) like UPPER('%' || :filter || '%')`, {
                        filter: filter.value,
                    });
                    break;
                case 'in':
                    if (Array.isArray(filter.value)) {
                        val[last] = In(filter.value);
                    }
                    break;
                case 'not in':
                    if (Array.isArray(filter.value)) {
                        val[last] = Not(In(filter.value));
                    }
                    break;
                default:
                    return res;
            }
        }
        return res;
    }, {});
};

export const sortEntity = (
    entity: EntityMetadata,
    target: string | string[] | qs.ParsedQs | qs.ParsedQs[] | Order[] = [],
) => {
    if (typeof target === 'string' && target.startsWith('{')) {
        target = [JSON.parse(target)];
    }
    if (typeof target === 'string' && target.startsWith('[')) {
        target = JSON.parse(target);
    }
    if (Array.isArray(target)) {
        if (typeof target[0] === 'string') {
            target = target.map((val) => JSON.parse(val));
        }
    } else {
        target = [];
    }
    return entity.columns.reduce((res, meta: ColumnMetadata) => {
        const order = (target as Order[]).find((val) =>
            val.property
                ? val.property.split('.')[0] === meta.propertyName || val.property === meta.databaseName
                : false,
        );
        if (order && order.direction) {
            const orderProperties = order.property.split('.');
            if (orderProperties.length > 1) {
                const last = orderProperties.pop();
                orderProperties.reduce((result, value) => {
                    result[value] = {};
                    return result[value];
                }, res)[last] = order.direction.toUpperCase();
            } else {
                res[meta.propertyName] = order.direction.toUpperCase();
            }
        }
        return res;
    }, {});
};
